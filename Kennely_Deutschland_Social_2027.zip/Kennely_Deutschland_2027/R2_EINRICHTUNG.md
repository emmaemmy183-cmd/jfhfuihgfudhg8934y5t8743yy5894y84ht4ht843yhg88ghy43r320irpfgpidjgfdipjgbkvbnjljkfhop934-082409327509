# Reels auf Cloudflare R2 speichern

**Warum R2?** Turso speichert Konten, Texte und Nachrichten. Videos belegen schnell sehr viel Speicher. R2 hält Videodateien getrennt und privat. Ohne R2 ist der Videoupload deaktiviert, statt 18-MB-Dateien in Turso abzulegen.

## Einrichtung

1. Im Cloudflare Dashboard zu **Storage & databases → R2** gehen und die R2-Nutzung aktivieren. Dafür kann eine Abrechnungseinrichtung verlangt werden.
2. Einen Bucket mit dem Namen `kennely-videos` und der **Standard**-Speicherklasse erstellen. Nicht öffentlich freigeben.
3. Nach erfolgreicher Einrichtung in `wrangler.jsonc` auf der obersten Ebene ergänzen:

```jsonc
"r2_buckets": [
  { "binding": "MEDIA_BUCKET", "bucket_name": "kennely-videos" }
]
```

   Auf das Komma vor/nach der Zeile achten. Die bestehenden `assets`, `durable_objects` und `migrations` unverändert lassen.
4. Für den lokalen Betrieb entweder einen lokalen R2-Bucket durch Wrangler emulieren oder die entsprechende Preview-Binding-Konfiguration verwenden. Für die produktive Domain muss der Bucket vorhanden und für den Worker gebunden sein.
5. Mit `npm run deploy` den Worker aktualisieren.
6. Ein Testvideo (MP4 oder WebM, unter 18 MB) hochladen. Es darf **nicht** vor der Freigabe durch Mitarbeitende im öffentlichen Feed erscheinen.

## Preise, Sicherheit und Grenzen

Cloudflare R2 Standard bietet derzeit 10 GB-Monate, 1 Million Class-A- und 10 Millionen Class-B-Operationen pro Monat als kostenloses Kontingent. Über den Freigrenzen kann die Nutzung kostenpflichtig werden. Das sind **keine unbegrenzten kostenlosen Videos**.

Dateizugriff erfolgt über den gesicherten Kennely-Backend-Endpunkt. Der Bucket darf nicht als öffentlicher Dateiserver freigeschaltet werden. Die Anwendung prüft Typ, Magic Bytes, Berechtigung und Moderationsstatus. Das beseitigt nicht alle Risiken durch schädliche oder illegale Videos; dafür braucht es fortlaufende Moderation und gegebenenfalls serverseitige Transkodierung und Malware-Scanning.

Aktuelle offizielle Angaben: https://developers.cloudflare.com/r2/pricing/ und https://developers.cloudflare.com/r2/get-started/
