# Kennely einrichten und veröffentlichen

## 1. Sicherheit und Datensicherung

Erstelle zuerst Backups von beiden Turso-Datenbanken. Kennely erweitert Tabellen und setzt vorhandene Beiträge vorsichtshalber auf **„Freigabe ausstehend“**, damit ältere Inhalte nicht ungeprüft online gehen. Bestehende Konten und Direktnachrichten werden nicht absichtlich gelöscht.

Früher veröffentlichte Turso- oder SendPulse-Keys müssen **widerrufen und neu erzeugt** werden. Ebenso einen neuen langen zufälligen `IP_HASH_SECRET` erstellen.

## 2. Lokale Einrichtung unter Windows

In den neu entpackten Projektordner gehen:

```powershell
npm install
Copy-Item .dev.vars.example .dev.vars
notepad .dev.vars
```

Wenn `.dev.vars` bereits existiert: **nicht überschreiben**. In Notepad mit `Strg + S` speichern. Wenn das scheitert, Datei am richtigen Pfad und Schreibrechte kontrollieren.

Benötigte Einträge:

```ini
TURSO_MAIN_URL="libsql://DEINE-HAUPTDATENBANK.turso.io"
TURSO_MAIN_TOKEN="NEUER_PRIVATER_TOKEN"
TURSO_MEDIA_URL="libsql://DEINE-MEDIENDATENBANK.turso.io"
TURSO_MEDIA_TOKEN="NEUER_PRIVATER_TOKEN"
IP_HASH_SECRET="LANGER_ZUFAELLIGER_PRIVATER_WERT"
PUBLIC_ORIGIN="http://127.0.0.1:8787"
COUNTRY_LOCK="DE"
LEGACY_DATING_ENABLED="false"
REGISTRATION_MODE="local"
MAIL_ENABLED="false"
SENDPULSE_API_KEY="NEUER_PRIVATER_KEY"
MAIL_FROM="no-support@kennely.de"
MAIL_REPLY_TO="support@kennely.de"
```

Die lokalen URL-Adressen **ohne die Tokens auszugeben** prüfen:

```powershell
Select-String -Path .dev.vars -Pattern '^TURSO_(MAIN|MEDIA)_URL='
```

Wenn dort noch `MAIN-DB.turso.io` oder `MEDIA-DB.turso.io` steht, sind weiterhin Beispiele eingetragen.

```powershell
npm run db:check
```

Erst nach erfolgreicher Verbindung und **Datensicherung**:

```powershell
npm run db:migrate
npm run db:schema
npm test
npm run dev
```

Lokal: `http://127.0.0.1:8787`. Die HTML-Seiten können auch ohne Datenbank geladen werden, die API aber nicht.

## 3. CEO und Team

1. Ein eigenes Kennely-Konto mit der gewünschten Betreiber-E-Mail anlegen.
2. Den Server anhalten und im Projektordner ausführen:

```powershell
npm run owner:assign -- mahmoudbankousli@gmail.com
```

3. Abmelden und erneut anmelden. Im Team-Bereich neue Mitarbeitende zuweisen. Ihre Aufgaben werden serverseitig auf Basis der Rolle kontrolliert. Im öffentlichen Profil erscheint **Kennely Team**, nicht die genaue Rolle.
4. Registriere ein separates offizielles Kennely-Mitgliedskonto mit einer erreichbaren E-Mail-Adresse und verwende:

```powershell
npm run official:assign -- support@kennely.de
```

Nur wenn dieses Mitgliedskonto tatsächlich existiert. Das Kennzeichen verleiht keine Administratorrechte.

## 4. E-Mail-Versand mit SendPulse

1. Domain `kennely.de` in SendPulse für den Versand authentifizieren (SPF, DKIM, DMARC bei dem **tatsächlich zuständigen DNS-Anbieter** setzen).
2. Die beiden bereits vorgesehenen Adressen verwenden: `no-support@kennely.de` als Absender und `support@kennely.de` als Reply-To.
3. Einen **neu erzeugten** SendPulse-API-Key lokal sowie später als Cloudflare Secret speichern.
4. Eine tatsächliche Registrierungsmail und einen Passwort-Reset testen.
5. Erst dann `MAIL_ENABLED="true"` in der produktiven Umgebung und nach Prüfung `REGISTRATION_MODE="public"` setzen. Sonst bei `closed` belassen.

## 5. Online auf Cloudflare Workers

```powershell
npx wrangler login
npm run deploy
```

Im Cloudflare Dashboard unter **Workers & Pages → kennely-app → Settings → Variables and Secrets**:

| Variable | Typ | Wert |
|---|---|---|
| `TURSO_MAIN_URL` | Text | aktuelle echte URL |
| `TURSO_MAIN_TOKEN` | Secret | neu ausgestellter Token |
| `TURSO_MEDIA_URL` | Text | aktuelle echte URL |
| `TURSO_MEDIA_TOKEN` | Secret | neu ausgestellter Token |
| `IP_HASH_SECRET` | Secret | eigener neuer zufälliger Wert |
| `SENDPULSE_API_KEY` | Secret | neuer Key, sobald aktiviert |
| `PUBLIC_ORIGIN` | Text | `https://kennely.de` |
| `COUNTRY_LOCK` | Text | `DE` |
| `LEGACY_DATING_ENABLED` | Text | `false` |
| `MAIL_ENABLED` | Text | zunächst `false` |
| `REGISTRATION_MODE` | Text | zunächst `closed` |
| `MAIL_FROM` | Text | `no-support@kennely.de` |
| `MAIL_REPLY_TO` | Text | `support@kennely.de` |

**Achtung:** `.dev.vars` wird nur lokal verwendet. Der Live-Worker benötigt die Werte separat in Cloudflare. Nach dem Ändern neu veröffentlichen oder den Worker redeployen.

Im Worker unter **Settings → Domains & Routes → Custom Domain** die Domain `kennely.de` hinzufügen, **wenn** die DNS-Zone bei dir in Cloudflare aktiv ist. Der Domainkauf bei one.com ist unabhängig davon. DNS/Nameserver nicht ohne Sicherung ändern.

Die Standortbeschränkung verwendet den von Cloudflare ermittelten Ländercode vor Seiten **und API**. Für echte Deutschland-Tests eine deutsche Verbindung verwenden. VPN und Geo-IP-Fehler bleiben möglich.

## 6. Reels

Videos **funktionieren erst mit der zusätzlichen R2-Konfiguration**. Details in `R2_EINRICHTUNG.md`. Ohne R2 bleiben Bilder, Text, Storys, Profilfunktionen und Nachrichten nutzbar.

## 7. Smoke-Test vor der Freigabe

- Startseite auf Handy, Tablet, Desktop und mit dem dunklen Modus öffnen.
- Registrierung, E-Mail-Bestätigung, Passwort-Reset und Login testen.
- Foto-Upload über `+`, Beitrag, Story, Video (mit R2) und Kommentar: **erst nach Teamfreigabe öffentlich sichtbar**.
- Mitarbeiter kann freigeben, ablehnen, weiterleiten und eine Begründung hinzufügen.
- Nachrichtenanfrage, Annahme, Tippanzeige, Echtzeit-Nachricht, rote Benachrichtigungszähler.
- Blauer Teamhaken und CEO-Kennzeichnung bei richtigen Konten.
- Gemeldete Chatbelege nur für CEO und nur mit nachvollziehbarer Begründung.
- Blockieren, Melden, Verwarnen, Sperren, Support und Einsprüche mit Bestätigungen testen.
- Datenexport, Konto- und Datenlöschung, Impressum, Datenschutz und Nutzungsbedingungen öffnen.
- Von außerhalb Deutschlands die Länderbegrenzung prüfen. Kein Test beweist hundertprozentige Geo-Sperre.
