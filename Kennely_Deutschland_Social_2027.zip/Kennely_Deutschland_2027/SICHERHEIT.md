# Interne Sicherheitsdokumentation von Kennely

Dieses Dokument bleibt im Quellprojekt und wird **nicht** als öffentliches Warnbanner angezeigt.

## Bereits implementiert

- Sichere serverseitige Rechteprüfung, getrennte Teamrollen, privilegierte CEO-Ernennung über lokales Script.
- Geheimnisse in `.dev.vars` und Cloudflare Worker Secrets, niemals im Frontend.
- Signierte/geschützte Sitzungscookies und gehashte Passwörter, Rate-Limits für wichtige Aktionen.
- Nicht freigegebene Beiträge, Storys, Fotos und Videos werden nicht öffentlich angezeigt; deren Freigabe-/Ablehnungs-Workflow ist protokolliert.
- Gesperrte Nutzer und Blockierungen werden bei API-Aufrufen berücksichtigt.
- Chat-Meldungen erfassen nur die durch den meldenden Teilnehmer eingereichten maximal 20 Nachrichten; CEO-Zugriff auf Belege verlangt eine schriftlich erfasste Begründung und wird auditiert. Kein beliebiges Durchsuchen fremder DMs.
- Behördenanfragen werden nur dokumentiert; keine automatische Datenherausgabe. Identität, Zuständigkeit, Rechtsgrundlage und Umfang sind im Einzelfall zu prüfen.
- Deutschlandbasierte Geo-IP-Sperre für HTML und API mit HTTP 451 (VPN/Geolokalisierungsfehler können die Länderbeschränkung umgehen).
- Vorgesehene Sicherheitsheader und kein eingebautes Werbetracking.

## Vor Produktion zusätzlich prüfen

- **Alle** früher veröffentlichten Tokens und `IP_HASH_SECRET` widerrufen/rotieren.
- Unabhängige Sicherheitsprüfung für XSS, CSRF, SQL, hochgeladene Medien, DMs und vertikale Rechteausweitung.
- Echte E-Mail-Zustellung, Domain-Authentifizierung und Sender-Reputation testen.
- Detailliertes Lösch- und Backup-Konzept sowie Monitoring von Kontingenten, Abuse, Logs und Meldefristen.
- Medien mit serverseitiger Verarbeitung/Schadcode- und Inhaltsprüfung behandeln; aktuell können nur Magic Bytes geprüft werden.
- Freigaben durch geschulte Personen, Eskalationsprozesse und Missbrauchsreaktionen sicherstellen.
- Kein System ist nach ausschließlich automatisierten Tests nachweislich frei von Bugs oder rechtlichen Risiken.
