# Interne Rechts- und Datenschutzprüfung

Die **öffentlichen** Seiten `/legal/impressum`, `/legal/datenschutz` und `/legal/nutzungsbedingungen` sind ohne Entwurfsbanner gestaltet. Dieses Dokument wird nicht öffentlich ausgeliefert.

Die vorhandenen deutschen Texte beschreiben den vorgesehenen Betreiber, Hosting, Datenbanken, E-Mails, Cookies, Beiträge, Moderation, DMs, CEO-Zugriff nur auf gemeldete Belege, Nutzerrechte und Behördenanfragen. Ihre Richtigkeit hängt von der tatsächlich verwendeten Infrastruktur und organisatorischen Abläufen ab. Es ist nicht möglich, durch Quellcode oder einen generierten Text eine vollständige Rechtssicherheit oder Straffreiheit zu garantieren.

Vor dem öffentlichen Betrieb prüfen: § 5 DDG, Art. 12–22, 28, 32 und 44 ff. DSGVO, Pflichten des Digital Services Act für die konkrete Diensteart, Art der Zustimmung und Nutzungsbedingungen, Urheber- und Bildrechte, Jugendschutz, Datenspeicherfristen, Zugriff auf DMs, DSA-Meldungen und Einsprüche, Aufbewahrung von Moderationsbelegen, Sicherheitsvorfälle und gegebenenfalls Unternehmens-/Gewerbeangaben.

Offizielle Ressourcen:
- https://www.gesetze-im-internet.de/ddg/__5.html
- https://www.bundesnetzagentur.de/DE/Fachthemen/DSC/1_Themen/PflichtenVermittlunggsdienste/start.html
- https://www.bfdi.bund.de/DE/Buerger/Inhalte/Allgemein/Datenschutz/Datenschutzgrundverordnung.html
