# Kennely Deutschland 2027.5

**Kennely** ist eine deutsche Social-Media-Web-App für `kennely.de`. Sie verbindet einen vertrauten Feed mit einem bewussteren **Kennely Moment**: ein täglicher Gesprächsimpuls anstelle eines rein endlosen Stroms von Beiträgen. Die responsive Oberfläche hat eine Desktop-Navigation, eine mobile Navigation, einen echten dunklen Modus und eine **ausschließlich deutsche Benutzeroberfläche**.

## Funktionen

- Feed, Entdecken, Beiträge, Reels, Nutzernamensuche, Speichern, Likes und Kommentare.
- Fotos, Textbeiträge, Storys (24 Stunden), Videos (MP4/WebM, mit optionaler privater R2-Anbindung), Follower und Profile unter `/profil/<id>`.
- **Vorabmoderation:** Beiträge, Kommentare, Storys, Fotos und Videos erscheinen erst nach Freigabe durch berechtigte Kennely-Mitarbeitende. Bei Medienprüfung können Fälle mit einer Nachricht weitergeleitet werden.
- Direktnachrichten, Anfrageannahme, Tippindikatoren, Live-Mitteilungen über Durable Objects und Fallback-Aktualisierung.
- Offizieller Kennely-Feed, blaues Häkchen für offizielle Konten und Kennely-Mitarbeiter, öffentlicher Hinweis **Kennely Team**. Beim Owner wird stattdessen zusätzlich **CEO** angezeigt; andere Teamrollen werden nicht im öffentlichen Profil angezeigt.
- Rollenbasierte Administration, Verwarnungen, Einschränkungen, Sperren, Meldungen und Einsprüche, Supportfälle, optionale Transaktionsmails über SendPulse.
- Private DMs sind nicht frei einsehbar. **Bei einer durch den Chat-Teilnehmer eingereichten Meldung** können maximal 20 zugehörige Nachrichten als Beleg vom CEO mit protokollierter Begründung eingesehen werden.
- CEO-Verwaltung zur Dokumentation rechtmäßiger Behördenanfragen. Die Funktion gibt Daten **nicht automatisch** an Dritte heraus.
- Deutsche Rechtsseiten: `/legal/impressum`, `/legal/datenschutz`, `/legal/nutzungsbedingungen`.
- **Geobeschränkung:** Bei Cloudflare in der Produktion werden Länder außerhalb Deutschlands per Geo-IP mit HTTP 451 abgewiesen. Lokale Tests bleiben erreichbar. Ein VPN oder falsche IP-Lokalisierung kann die Beschränkung umgehen.

## Installation unter Windows

Siehe **[EINRICHTUNG.md](EINRICHTUNG.md)**. Schnellstart, wenn `.dev.vars` bereits korrekt ausgefüllt ist:

```powershell
npm install
npm run db:check
# Beide Turso-Datenbanken vorher sichern!
npm run db:migrate
npm run db:schema
npm test
npm run dev
```

Anschließend `http://127.0.0.1:8787` aufrufen.

### CEO und offizielles Kennely-Konto

Nach Anlage eines eigenen Kennely-Mitgliedskontos:

```powershell
npm run owner:assign -- mahmoudbankousli@gmail.com
```

Das geht einmalig, solange kein Owner existiert. Danach erneut anmelden. Ein **separat registriertes** offizielles Kennely-Konto kannst du so kennzeichnen:

```powershell
npm run official:assign -- support@kennely.de
```

Die E-Mail-Adresse muss zu einem tatsächlich angelegten Mitgliedskonto gehören. Ein reiner SendPulse-Absender ist kein Benutzerkonto. Eine offizielle Kennzeichnung allein verleiht keine Teamrechte.

## Datenhaltung und Kosten

- **Turso Hauptdatenbank:** Benutzer, Sitzungen, Profile, Beiträge, Chatnachrichten, Meldungen, Freigaben, Auditprotokolle.
- **Turso Mediendatenbank:** optimierte Profil- und Beitragsbilder. Der Upload ist auf 650 KB pro Bild begrenzt.
- **Optional Cloudflare R2:** private Videodateien. Ohne R2-Binding gibt der Videoupload einen verständlichen 503-Fehler zurück, statt Turso mit Videos zu füllen. Anleitung in **R2_EINRICHTUNG.md**.
- **Cloudflare Workers:** Weboberfläche, API, Zugangsschutz, Echtzeit-Durable-Object.
- **SendPulse:** Registrierungs- und Supportmails, nur nach aktivierter Konfiguration.

Das System verwendet Seiten von jeweils bis zu 20 Feed-Beiträgen, Indizes und Lazy Loading. Es ist nicht grenzenlos skalierbar; kostenlose Anbieter haben Kontingente und können bei Mehrverbrauch kostenpflichtig werden.

## Architektur

```text
public/                Deutsche Oberfläche, CSS, JS, Icons, rechtliche Seiten
src/server/index.js     Worker-Routing, Zugriffsschutz, Auth, Geo-Filter
src/server/social.js    Feed, Reels, Storys, Uploads, Moderation, DMs
src/server/features.js  Einstellungen, Team, Tickets, Benachrichtigungen
src/server/live.js      Live-Updates und Durable Object
db/                    Datenbankschemata einschließlich deutschland.sql
scripts/               Sicheres Setup, Migration, Rollenzuweisung
tests/                 Automatisierte API- und Berechtigungstests
```

**Sicherheit:** Die ZIP enthält keine Zugangsschlüssel. `.dev.vars` niemals veröffentlichen oder in GitHub einchecken. Alle zuvor in einem Chat geteilten Tokens und der alte `IP_HASH_SECRET` sind zu ersetzen.

**Veröffentlichung:** Die lokal bestandenen Tests ersetzen keine realen Tests mit deiner produktiven Domain, dem E-Mail-Versand, echten Geräten und den rechtlichen Unterlagen. Die öffentlichen Rechtsseiten enthalten keine Entwurfsbanner; die interne Prüfliste befindet sich separat in `VOR_DEM_LAUNCH.md`.
