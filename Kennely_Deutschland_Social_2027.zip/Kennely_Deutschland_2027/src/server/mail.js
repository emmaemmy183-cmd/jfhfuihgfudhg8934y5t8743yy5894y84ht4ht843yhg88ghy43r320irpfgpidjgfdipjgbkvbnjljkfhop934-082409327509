/** Transactional SendPulse API, server-side only. Send only necessary emails. */
export function configured(env){return env.MAIL_ENABLED==='true' && !!env.SENDPULSE_API_KEY && /^https:\/\//.test(env.PUBLIC_ORIGIN||'');}
export async function sendMail(env,{to,subject,text}) {
  if (!configured(env)) throw new Error('Mail provider not configured for production.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(to))) throw new Error('Invalid recipient');
  if (!['no-support@kennely.de','support@kennely.de'].includes(env.MAIL_FROM)) throw new Error('Invalid configured sender');
  if (!String(text).trim() || String(text).length>5000) throw new Error('Invalid email');
  const payload={email:{text,subject,from:{name:'Kennely',email:env.MAIL_FROM},
    to:[{email:to}],reply_to:{name:'Kennely Support',email:env.MAIL_REPLY_TO||'support@kennely.de'}}};
  const response=await fetch('https://api.sendpulse.com/smtp/emails',{method:'POST',
    headers:{'Authorization':`Bearer ${env.SENDPULSE_API_KEY}`,'Content-Type':'application/json'},
    body:JSON.stringify(payload)});
  const result=await response.json().catch(()=>null);
  if(!response.ok || result?.result!==true)throw new Error(`Email provider declined request (${response.status}).`);
  return {ok:true,providerId:result.id||null};
}
