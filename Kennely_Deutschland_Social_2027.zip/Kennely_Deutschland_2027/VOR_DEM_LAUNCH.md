# Interne Freigabeliste: Kennely Deutschland

Diese Liste gehört zum internen Projekt, nicht zu den öffentlichen Rechtsseiten.

- [ ] Haupt- und Mediendatenbank gesichert, neue Migration erfolgreich, Rollback getestet.
- [ ] Alle veröffentlichten Tokens gewechselt, Worker-Secrets geschützt, kein Key im Repository.
- [ ] Deutschland-Filter auf Cloudflare Workers **vor** allen Assets und APIs geprüft. VPN-Umgehbarkeit berücksichtigen.
- [ ] SendPulse für `kennely.de` eingerichtet und E-Mail-Bestätigung, Passwort-Reset und Mail-Domain-Schutz getestet.
- [ ] Wenn Reels aktiviert werden: R2-Standard-Bucket privat und korrekt gebunden; Nutzungslimits und Kostenwarnungen gesetzt.
- [ ] Profilfotos, Bilder, Videos, Texte, Storys und Kommentare: vor Freigabe nicht öffentlich; negatives Berechtigungstesting für normale Mitglieder.
- [ ] Rechte für CEO, Admin, Manager, Moderator, Support und die offiziellen Konten getestet.
- [ ] Dokumentierte Meldungen, Moderationsbegründungen, Einsprüche, Nutzerinformationen und relevante DSA-Pflichten geprüft; DSA-Regeln können abhängig von Diensteart und Größe unterschiedlich gelten.
- [ ] Zugriff auf gemeldete Chatbelege nachweislich beschränkt und auditiert; keine allgemeine Lesefunktion.
- [ ] Auskunftsprozesse, vollständiger Datenexport, Löschung, Aufbewahrungsfristen und Backup-Löschungen verifiziert.
- [ ] Betreiberinformationen, rechtlich erforderliche Kontaktdaten und Impressum unter § 5 DDG auf tatsächlich vorhandene Angaben geprüft.
- [ ] Datenschutzerklärung mit **tatsächlichen** Dienstleistern, Datenkategorien, Zwecken, Rechtsgrundlagen und möglichen Drittlandtransfers abgestimmt. Auftragsverarbeitungsverträge geprüft.
- [ ] Urheberrecht, Persönlichkeitsrechte, Kinder- und Jugendschutz sowie verbotene Inhalte und Moderationskapazitäten geprüft.
- [ ] Sicherheits-, Performance- und browserübergreifende End-to-End-Tests und echte Produktiv-Deploytests abgeschlossen.

**Rechtsquellen:** https://www.gesetze-im-internet.de/ddg/__5.html · https://www.bundesnetzagentur.de/DE/Fachthemen/DSC/1_Themen/PflichtenVermittlunggsdienste/start.html · https://eur-lex.europa.eu/eli/reg/2016/679/oj
